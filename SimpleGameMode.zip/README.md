### SimpleGameMode

Simple Gamemode Plugin :D

### Commands
|**Command**|**Description**|
|-----------|---------------|
|`/gms`|Survival Mode|
|`/gmc`|Creative Mode|
|`/gma`|Adventure Mode|
|`/gmspc`|Spectator Mode|

©RianDev
